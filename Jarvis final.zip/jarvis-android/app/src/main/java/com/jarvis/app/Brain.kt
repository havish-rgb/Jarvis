package com.jarvis.app
import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Prefs {
  fun get(c: Context): SharedPreferences = EncryptedSharedPreferences.create(c, "jarvis",
    MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV, EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
}
object Brain {
  fun ask(c: Context, system: String, user: String): String {
    val p = Prefs.get(c)
    val body = JSONObject().put("model", p.getString("model", "anthropic/claude-sonnet-4.5")).put("messages", JSONArray()
      .put(JSONObject().put("role", "system").put("content", system))
      .put(JSONObject().put("role", "user").put("content", user)))
    val k = URL(p.getString("endpoint", "https://openrouter.ai/api/v1/chat/completions")).openConnection() as HttpURLConnection
    k.requestMethod = "POST"; k.doOutput = true; k.connectTimeout = 20000; k.readTimeout = 60000
    k.setRequestProperty("Authorization", "Bearer " + p.getString("key", ""))
    k.setRequestProperty("Content-Type", "application/json")
    k.outputStream.use { it.write(body.toString().toByteArray()) }
    val s = (if (k.responseCode < 400) k.inputStream else k.errorStream).bufferedReader().readText()
    return JSONObject(s).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
  }
  fun json(s: String) = JSONObject("{" + s.substringAfter("{").substringBeforeLast("}") + "}")
}

object Memory {
  fun all(c: Context): String = Prefs.get(c).getString("mem", "") ?: ""
  fun add(c: Context, f: String) { Prefs.get(c).edit().putString("mem", (all(c) + "\n- " + f).takeLast(8000)).apply() }
  fun clear(c: Context) { Prefs.get(c).edit().remove("mem").apply() }
}
