package com.jarvis.app
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import android.provider.ContactsContract
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONObject
import java.util.Locale
import android.media.AudioManager
import android.view.KeyEvent

const val PLAN = """You are JARVIS, Sir's phone assistant. Understand any request in natural language. Sir's saved memory comes with each request; use it. Reply ONLY JSON:
{"say":"short spoken reply ending with 'sir'","action":"open_app|call|agent|media|none","app":"app name","contact":"name to call","number":"digits if given","goal":"full goal for the screen agent","cmd":"next|previous|pause|play","remember":"fact to save permanently, else empty","forget":false,"confirm":false}
Use "agent" for anything done inside an app (create project, edit style, export, play a song in Spotify, search). Use "media" for next, previous, pause or play of the current audio. When Sir says remember something, put it in "remember". When Sir wants something built in Claude, set app to Claude and write a complete, detailed build prompt yourself inside goal: open Claude, start a new chat, type that exact prompt, press send. Set confirm=true for calls and for anything that sends, posts, pays or deletes that Sir did not ask for. Exporting, or sending a prompt Sir asked for, needs no confirm."""
const val STEP = """You control an Android phone screen to reach GOAL. You get the visible screen text. Reply ONLY JSON:
{"do":"click|tap|type|scroll|back|open|done|ask","text":"label to click, text to type or app to open","x":0,"y":0,"say":"optional short spoken update"}
Use "tap" with x,y for [icon at x,y] items. Use "done" when the goal is complete. Use "ask" (say the question) only before sending, posting, paying or deleting that GOAL did not request. Pick editing choices yourself from the goal's style."""

class JarvisService : Service(), TextToSpeech.OnInitListener {
  private lateinit var tts: TextToSpeech
  private var sr: SpeechRecognizer? = null
  private val h = Handler(Looper.getMainLooper())
  @Volatile private var speaking = false
  @Volatile private var running = false
  private var pending: JSONObject? = null
  private var lastHeard = 0L

  override fun onBind(i: Intent?): IBinder? = null
  override fun onCreate() {
    super.onCreate()
    val nm = getSystemService(NotificationManager::class.java)
    nm.createNotificationChannel(NotificationChannel("j", "JARVIS", NotificationManager.IMPORTANCE_LOW))
    val n = Notification.Builder(this, "j").setContentTitle("JARVIS is listening").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
    startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    tts = TextToSpeech(this, this)
  }
  override fun onInit(s: Int) {
    tts.language = Locale.getDefault()
    tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
      override fun onStart(id: String?) { speaking = true; h.post { sr?.cancel() } }
      override fun onDone(id: String?) { speaking = false; h.post { listen() } }
      @Deprecated("x") override fun onError(id: String?) { speaking = false; h.post { listen() } }
    })
    say("At your service, sir. What do we do today?")
  }
  fun say(t: String) { if (t.isBlank()) return; speaking = true; tts.speak(t, TextToSpeech.QUEUE_ADD, null, "u" + System.nanoTime()) }

  private fun listen() {
    if (speaking) return
    sr?.destroy(); sr = SpeechRecognizer.createSpeechRecognizer(this)
    sr!!.setRecognitionListener(object : RecognitionListener {
      override fun onResults(b: Bundle?) { b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { handle(it) }; h.postDelayed({ listen() }, 400) }
      override fun onError(e: Int) { h.postDelayed({ listen() }, 800) }
      override fun onReadyForSpeech(p: Bundle?) {}; override fun onBeginningOfSpeech() {}; override fun onRmsChanged(r: Float) {}
      override fun onBufferReceived(b: ByteArray?) {}; override fun onEndOfSpeech() {}
      override fun onPartialResults(b: Bundle?) {}; override fun onEvent(t: Int, b: Bundle?) {}
    })
    sr!!.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM))
  }

  private fun handle(raw: String) {
    val low = raw.lowercase(); val now = System.currentTimeMillis()
    if (!low.contains("jarvis") && now - lastHeard > 60000) return
    lastHeard = now
    if (Regex("\\bstop\\b|\\bcancel\\b").containsMatchIn(low)) { running = false; pending = null; say("Stopped, sir."); return }
    val t = raw.replace(Regex("(?i)jarvis"), "").trim()
    pending?.let { p -> pending = null; if (Regex("allow|yes|proceed|go ahead").containsMatchIn(low)) exec(p) else say("Cancelled, sir."); return }
    if (t.isEmpty()) { say("Yes, sir?"); return }
    Thread {
      try {
        val r = Brain.json(Brain.ask(this, PLAN, "SIR'S MEMORY:\n" + Memory.all(this) + "\nREQUEST: " + t)); say(r.optString("say"))
        if (r.optString("remember").isNotBlank()) Memory.add(this, r.optString("remember"))
        if (r.optBoolean("forget")) Memory.clear(this)
        if (r.optBoolean("confirm")) { pending = r; say("Say allow to proceed.") } else exec(r)
      } catch (e: Exception) { say("I can't reach my brain, sir. Please check the API key.") }
    }.start()
  }

  private fun exec(r: JSONObject) {
    when (r.optString("action")) {
      "media" -> media(r.optString("cmd"))
      "open_app" -> if (!launch(r.optString("app"))) say("I couldn't find that app, sir.")
      "call" -> call(r.optString("number"), r.optString("contact"))
      "agent" -> Thread { if (r.optString("app").isNotBlank()) { launch(r.optString("app")) }; agent(r.optString("goal")) }.start()
    }
  }
  private fun media(c: String) {
    val k = when (c) { "next" -> KeyEvent.KEYCODE_MEDIA_NEXT; "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS; "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE; else -> KeyEvent.KEYCODE_MEDIA_PLAY }
    val am = getSystemService(AudioManager::class.java)
    am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, k)); am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, k))
  }
  private fun go(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); (JarvisAccess.I ?: this as android.content.Context).startActivity(i) }
  private fun launch(name: String): Boolean {
    val pm = packageManager
    val a = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
      .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name.lowercase()) } ?: return false
    go(pm.getLaunchIntentForPackage(a.activityInfo.packageName) ?: return false); return true
  }
  private fun call(num: String, name: String) {
    var n = num
    if (n.isBlank()) contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
      ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", arrayOf("%$name%"), null)?.use { if (it.moveToFirst()) n = it.getString(0) }
    if (n.isBlank()) { say("I couldn't find that contact, sir."); return }
    go(Intent(Intent.ACTION_CALL, android.net.Uri.parse("tel:" + n)))
  }
  private fun agent(goal: String) {
    running = true; val hist = StringBuilder(); var i = 0
    while (running && i++ < 30) {
      val a = JarvisAccess.I ?: run { say("Please enable my accessibility access, sir."); running = false; return }
      Thread.sleep(1500)
      val r = try { Brain.json(Brain.ask(this, STEP, "MEMORY:\n${Memory.all(this)}\nGOAL: $goal\nDONE SO FAR:\n$hist\nSCREEN:\n${a.dump()}")) } catch (e: Exception) { say("I lost my connection, sir."); running = false; return }
      say(r.optString("say")); val x = r.optString("text")
      when (r.optString("do")) {
        "click" -> a.click(x); "type" -> a.type(x); "scroll" -> a.scroll(); "back" -> a.back()
        "tap" -> a.tap(r.optInt("x"), r.optInt("y")); "open" -> launch(x)
        "done", "ask" -> { running = false; return }
      }
      hist.append(r.optString("do")).append(' ').append(x).append('\n')
    }
    if (running) say("I stopped after thirty steps, sir."); running = false
  }
  override fun onDestroy() { sr?.destroy(); tts.shutdown(); super.onDestroy() }
}
