package com.jarvis.app
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
  override fun onCreate(b: Bundle?) {
    super.onCreate(b)
    val p = Prefs.get(this)
    val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40); setBackgroundColor(Color.parseColor("#030b17")) }
    fun tv(t: String, s: Float, c: String) = TextView(this).apply { text = t; textSize = s; setTextColor(Color.parseColor(c)) }
    fun et(h: String, k: String, d: String, pw: Boolean = false) = EditText(this).apply { hint = h; setText(p.getString(k, d)); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
      if (pw) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
    fun bt(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
    val key = et("API key (OpenRouter)", "key", "", true); val model = et("Model", "model", "anthropic/claude-sonnet-4.5"); val ep = et("Endpoint", "endpoint", "https://openrouter.ai/api/v1/chat/completions")
    col.addView(tv("J.A.R.V.I.S.", 32f, "#12daff")); col.addView(tv("Say \"Jarvis, ...\" — open apps, call, run any editing app.", 13f, "#6f9bb5"))
    listOf(key, model, ep).forEach { col.addView(it) }
    col.addView(bt("1. Save brain settings") { p.edit().putString("key", key.text.toString().trim()).putString("model", model.text.toString().trim()).putString("endpoint", ep.text.toString().trim()).apply(); Toast.makeText(this, "Saved", 0).show() })
    col.addView(bt("2. Grant mic / call / contacts") { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS, Manifest.permission.POST_NOTIFICATIONS), 1) })
    col.addView(bt("3. Turn on JARVIS in Accessibility") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
    col.addView(bt("4. Allow display over other apps") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) })
    col.addView(bt("START JARVIS") { startForegroundService(Intent(this, JarvisService::class.java)); Toast.makeText(this, "JARVIS is running in the background", 1).show() })
    setContentView(ScrollView(this).apply { addView(col) })
  }
}
